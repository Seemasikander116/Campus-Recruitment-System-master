import React from 'react';
const Footer = () => {
    return (
        <div>
            <footer className="page-footer transparent">
                <div className="container">
                </div>
                <div className="footer-copyright grey darken-3">
                    <div className="container center-align">
                        &copy; 2021 Campus Recruitment System <br />
                        Created By Seema Sikander<br />
				Sylani Course mobile and web development 
                    </div>
                </div>
            </footer>
        </div>
    );
}

export default Footer;